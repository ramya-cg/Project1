package com.capg.ban.services;

public interface IBankProjectService {
	
	 public double showBalance();
	public double deposit(double rupee);
	public double withdraw(double rupee);

	public void fundTransfer();
	public void Transactions();
	public boolean createAccount();

}
