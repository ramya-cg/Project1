package com.capg.ban.services;

import java.util.Scanner;

import com.capg.ban.bean.BankProject;
import com.capg.ban.dao.BankProjectDAOImp;

public class BankProjectServiceImp implements IBankProjectService {
	BankProjectDAOImp dao = new BankProjectDAOImp();
	@Override
	public boolean createAccount(){
		double balance = 500, rupee, with;

		long mobNumber;
		int n, age;
		BankProject bank = new BankProject();
		Scanner sca = new Scanner(System.in);
		System.out.println("Enter name of account holder :\t");
		String name = sca.next();
		System.out.println("Enter Mobile number of account holder :\t");
		mobNumber = sca.nextLong(10);
		System.out.println("Enter age of account holder :\t");
		age = sca.nextInt();
		bank.setName(name);
		bank.setMobNumber(mobNumber);
		bank.setAge(age);
		return dao.createAccount();
	}
	@Override
	public double showBalance() {
		// TODO Auto-generated method stub
		return dao.showBalance();
	}

	@Override
	public double deposit(double rupee) {
		// TODO Auto-generated method stub
		return dao.deposit(rupee);
	}

	@Override
	public double withdraw(double rupee) {
		// TODO Auto-generated method stub
		return dao.withdraw(rupee);
	}

	@Override
	public void fundTransfer() {
		// TODO Auto-generated method stub

	}

	@Override
	public void Transactions() {
		// TODO Auto-generated method stub

	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
