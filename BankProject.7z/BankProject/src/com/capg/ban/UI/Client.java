package com.capg.ban.UI;

import java.time.Instant;

//import java.util.Random;
import java.util.Scanner;

import com.capg.ban.bean.BankProject;
import com.capg.ban.services.BankProjectServiceImp;
import com.capg.ban.services.IBankProjectService;

public class Client {

	public static void main(String[] args) {
		double balance = 500, with;

		// long mobNumber;
		int n;
		IBankProjectService service = new BankProjectServiceImp();
		Scanner s = new Scanner(System.in);

		System.out.println(" Hai! Welcome to Rams Bank");
		while (true) {
			System.out
					.println(" 1. Creating Account\n 2. Show Balance \n 3. Deposit \n 4. Withdraw \n "
							+ "5. Fund Transfer \n 6. Print Transactions \n 7. Exit\n ");
			System.out.println("\nEnter your choice\n");
			n = s.nextInt();
			switch (n) {
			case 1:

				service.createAccount();
				break;

			case 2:

				service.showBalance();
				break;

			case 3:
				service.deposit(3000);
				break;
			case 4:

				System.out.println("Enter withdrawl amount for ");
				with = s.nextDouble();
				System.out.println(" Enter pin number");

				if (with >= balance) {
					System.err
							.println("You don't have sufficient balance to withdraw");
				} else {
					System.out.println("withdrawl amount: " + with);
					balance = balance - with;
					Instant currTime = Instant.now();
					System.out.println("Total amount of after withdrawl is: "
							+ balance + " at" + currTime);
				}
				service.withdraw(3000);
				break;

			case 5:
				service.fundTransfer();
				break;

			case 6:

				service.Transactions();
				break;

			case 7:

				System.out.println("\tThank you \n     Have a great day!!");
				System.exit(0);
			}

		}
	}
}
