package com.capg.ban.bean;

public class BankProject {
	 private int pin;
	 private String name,accType;
	 private long mobNumber, accNum;
	 private	double balance,rupee,with;
	 private int age,amo;
	 public int getPin() {
		return pin;
	}
	public void setPin(int pin) {
		this.pin = pin;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public long getAccNum() {
		return accNum;
	}
	public void setAccNum(long accNum) {
		this.accNum = accNum;
	}
	public long getMobNumber() {
		return mobNumber;
	}
	public void setMobNumber(long mobNumber) {
		this.mobNumber = mobNumber;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	public double getRupee() {
		return rupee;
	}
	public void setRupee(double rupee) {
		this.rupee = rupee;
	}
	public double getWith() {
		return with;
	}
	public void setWith(double with) {
		this.with = with;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public int getAmo() {
		return amo;
	}
	public void setAmo(int amo) {
		this.amo = amo;
	}
	@Override
	public String toString() {
		return "BankProject [pin=" + pin + ", name=" + name + ", accType="
				+ accType + ", mobNumber=" + mobNumber + ", balance=" + balance
				+ ", rupee=" + rupee + ", with=" + with + ", age=" + age
				+ ", amo=" + amo + "]";
	}
	
}
