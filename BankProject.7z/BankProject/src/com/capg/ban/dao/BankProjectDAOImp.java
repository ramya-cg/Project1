package com.capg.ban.dao;

import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.Scanner;
//import com.capg.ban.UI.Client;
import com.capg.ban.bean.BankProject;

public class BankProjectDAOImp implements IBankProjectDAO {
	List<BankProject> empList = new ArrayList<BankProject>();
	double balance = 500, rupee, with;
	long mobNumber, accNum, pin;
	int n, age, amo;
	Scanner s = new Scanner(System.in);

	@Override
	public boolean createAccount() {
		double balance = 500;
		/*
		 * long mobNumber, accNum, pin; int n, age;
		 */

		Random rand = new Random();
		accNum = rand.nextLong();
		if (accNum < 0) {
			accNum = accNum * -1;
		}

		System.out.println("Account number is: " + accNum);

		Random pi = new Random();
		pin = pi.nextInt();
		if (pin < 0) {
			pin = pin * -1;
		}
		// bank.getPin();
		System.out.println("Your pin is: " + pin);
		System.out.println(" your balance is " + balance);
		System.out.println("Account Created Successfully ");
		return true;
	}

	@Override
	public double showBalance() {
		// TODO Auto-generated method stub

		System.out
				.println("Enter your Account number and pin number to show balance");
		long accno = s.nextLong();
		long pinNum = s.nextLong();

		for (BankProject p : empList) {

			if (accno == p.getAccNum() && pinNum == p.getPin()) {
				double balance = p.getBalance();
				//System.out.println("Your balance is: " + balance);
			}
			System.out.println("Your balance is: " + balance);
		}
		return balance;
	}

	@Override
	public int deposit(double rupee) {
		// TODO Auto-generated method stub
		System.out.println("Enter deposit amount");
		rupee = s.nextDouble();
		Instant currentTime = Instant.now();
		System.out.println("Deposited amount of is: " + (rupee) + " at "
				+ currentTime);
		balance = balance + rupee;
		System.out.println("Total amount: " + (balance));
		return 0;
	}

	@Override
	public double withdraw(double rupee) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public void fundTransfer() {
		// TODO Auto-generated method stub

		System.out.println("Enter the account number you have to transfer: ");
		long acn = s.nextLong();
		System.out.println("Enter name of account holder: ");
		String hold = s.next();
		System.out.println("Enter IFSC Code: ");
		String cod = s.next();
		System.out.println("Enter Amount to be transfer: ");
		int amo = s.nextInt();
		if (amo >= balance) {
			System.err.println("You don't have sufficient balance");
		} else {
			System.out.println("\t" + hold + "\n\t" + acn + "\n\t" + cod
					+ "\n\t" + amo);
			System.out.println(" Money transfered successfully ");
			balance = balance - amo;
			System.out.println("Your balance is\n\t" + balance);
		}
	}

	@Override
	public void Transactions() {
		// TODO Auto-generated method stub
		System.out.println("Amount deposited " + rupee);
		System.out.println("Amount withdrawl " + with);
		System.out.println("Amount transfered" + amo);
		System.out.println("Balance amount " + balance);
	}

}
