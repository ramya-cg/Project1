package com.capg.ban.dao;

public interface IBankProjectDAO {

	public boolean createAccount();

	public double showBalance();

	public int deposit(double rupee);

	public double withdraw(double rupee);

	public void fundTransfer();

	public void Transactions();

}
