package com.capg.walletservice.dao;

import com.capg.walletservice.bean.AccountBean;

public interface IAccountDAO {

	public boolean createAccount(AccountBean accountBean) throws Exception;

	public boolean updateAccount(AccountBean accountBean) throws Exception;

	public AccountBean findAccount(int accountId) throws Exception;

}
