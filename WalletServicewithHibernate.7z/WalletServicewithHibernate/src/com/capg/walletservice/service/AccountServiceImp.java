package com.capg.walletservice.service;

import com.capg.walletservice.bean.AccountBean;
import com.capg.walletservice.dao.AccountDAOImp;
import com.capg.walletservice.dao.IAccountDAO;

public class AccountServiceImp implements IAccountService {

	@Override
	public boolean createAccount(AccountBean accountBean) throws Exception {
		IAccountDAO dao = new AccountDAOImp();
		boolean result = dao.createAccount(accountBean);
		return result;
	}

	@Override
	public boolean deposit(AccountBean accountBean, double depositAmount)
			throws Exception {
		accountBean.setBalance(accountBean.getBalance() + depositAmount);
		IAccountDAO dao = new AccountDAOImp();
		boolean result = dao.updateAccount(accountBean);
		return result;
	}

	@Override
	public boolean withdraw(AccountBean accountBean, double withdrawAmount)
			throws Exception {
		accountBean.setBalance(accountBean.getBalance() - withdrawAmount);
		IAccountDAO dao = new AccountDAOImp();
		boolean result = dao.updateAccount(accountBean);
		return result;
	}

	@Override
	public boolean fundTransfer(AccountBean accountBeanFrom,
			AccountBean accountBeanTo, double transferAmount)
			throws Exception {

		accountBeanFrom.setBalance(accountBeanFrom.getBalance()
				- transferAmount);
		accountBeanTo.setBalance(accountBeanTo.getBalance()
				+ transferAmount);

		IAccountDAO dao = new AccountDAOImp();
		boolean result1 = dao.updateAccount(accountBeanFrom);
		boolean result2 = dao.updateAccount(accountBeanTo);
		return result1 && result2;
	}

	@Override
	public AccountBean findAccount(int accountId) throws Exception {
		IAccountDAO dao = new AccountDAOImp();
		AccountBean bean = dao.findAccount(accountId);
		return bean;
	}

}
