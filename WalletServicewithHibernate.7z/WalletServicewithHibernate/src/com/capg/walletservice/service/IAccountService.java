package com.capg.walletservice.service;

import com.capg.walletservice.bean.AccountBean;

public interface IAccountService {

          public boolean createAccount(AccountBean accountBean) throws  Exception ;
          public AccountBean findAccount(int accountId) throws Exception;
          public boolean deposit(AccountBean accountBean,double depositAmount) throws Exception ;
          public boolean withdraw(AccountBean accountBean,double withdrawAmount) throws Exception;
          public boolean fundTransfer(AccountBean accountBeanFrom, AccountBean accountBeanTo, double transferAmount) throws Exception ;
         
		 
          
	
}

